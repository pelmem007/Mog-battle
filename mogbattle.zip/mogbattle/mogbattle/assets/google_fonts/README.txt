Сюда кладутся JetBrainsMono-Regular.ttf, -Medium.ttf, -Bold.ttf, -ExtraBold.ttf.
Скачать автоматически: bash scripts/fetch_assets.sh
