#!/usr/bin/env bash
# Скачивает Haar-каскад OpenCV и шрифт JetBrains Mono. Запускать из корня проекта.
set -euo pipefail

mkdir -p assets/google_fonts

echo "-> Haar cascade (opencv/opencv, 4.x)"
curl -fL -o assets/haarcascade_frontalface_default.xml \
  https://raw.githubusercontent.com/opencv/opencv/4.x/data/haarcascades/haarcascade_frontalface_default.xml

echo "-> JetBrains Mono"
tmp="$(mktemp -d)"
curl -fL -o "$tmp/jb.zip" \
  https://github.com/JetBrains/JetBrainsMono/releases/download/v2.304/JetBrainsMono-2.304.zip
unzip -q -o "$tmp/jb.zip" 'fonts/ttf/JetBrainsMono-*.ttf' -d "$tmp"
for w in Regular Medium Bold ExtraBold; do
  cp "$tmp/fonts/ttf/JetBrainsMono-$w.ttf" assets/google_fonts/
done
rm -rf "$tmp"
echo "Готово."
