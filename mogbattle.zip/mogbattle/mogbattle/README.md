# MogBattle

Фейковый AI-сканер лиц (Mr. Robot style). Без сети, без API, без INTERNET в манифесте.
Реальной остаётся только Haar-детекция лица (opencv_dart) для рамки и точек.

## Запуск
1. `flutter create --platforms=android --org com.mogbattle mogbattle`, затем скопировать
   поверх: `lib/`, `assets/`, `scripts/`, `pubspec.yaml`, `analysis_options.yaml`,
   `android/app/src/main/AndroidManifest.xml`.
2. `bash scripts/fetch_assets.sh` — Haar-каскад + JetBrains Mono
   (вручную: каскад из `opencv/opencv` → `data/haarcascades/`, шрифт с fonts.google.com;
   файлы `JetBrainsMono-Regular/Medium/Bold/ExtraBold.ttf` в `assets/google_fonts/`).
3. `flutter pub get`
4. `dart run build_runner build --delete-conflicting-outputs` (freezed + json_serializable)
5. `flutter run`

## Заметки
- В debug/profile манифестах Flutter сам добавляет INTERNET (hot reload). В release его нет.
- `GoogleFonts.config.allowRuntimeFetching = false` выставляется в main.dart: шрифты берутся из assets.
- opencv_dart: если сборка ругается на minSdk/NDK, смотри README пакета.
- Для публикации в Play добавь дисклеймер (`AppStrings.disclaimer`): приложение развлекательное.

## Прогресс
- [x] 1 pubspec + структура
- [x] 2 core: константы, тема, роутер, HUD-виджеты (`core/widgets`)
- [x] 3 модели + FakeAnalyzer
- [x] 4 FaceDetector
- [x] 5a home, opponent, upload + upload_provider
- [x] 5b analysis + neural + analysis_provider
- [x] 5c verdict + history + Hive-репозиторий + провайдеры
- [x] 6 main.dart, app.dart
