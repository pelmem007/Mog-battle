import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive_flutter/hive_flutter.dart';

import 'app.dart';
import 'core/constants/colors.dart';
import 'core/utils/face_detector.dart';
import 'features/history/application/history_provider.dart';
import 'features/history/data/battle_repository.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Сети нет: шрифты берём только из assets/google_fonts
  GoogleFonts.config.allowRuntimeFetching = false;

  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: AppColors.background,
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  await Hive.initFlutter();
  final repository = await BattleRepository.open();

  // Прогреваем Haar-каскад заранее, чтобы скан стартовал без паузы
  unawaited(FaceDetector.instance.init());

  runApp(
    ProviderScope(
      overrides: [battleRepositoryProvider.overrideWithValue(repository)],
      child: const MogBattleApp(),
    ),
  );
}
