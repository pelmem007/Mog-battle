import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../constants/colors.dart';

/// Короткий доступ к моноширинным стилям (JetBrains Mono).
abstract final class AppText {
  static TextStyle mono({
    double size = 14,
    FontWeight weight = FontWeight.w400,
    Color color = AppColors.textPrimary,
    double? letterSpacing,
    double? height,
  }) =>
      GoogleFonts.jetBrainsMono(
        fontSize: size,
        fontWeight: weight,
        color: color,
        letterSpacing: letterSpacing,
        height: height,
      );
}

/// Тёмная тема Mr. Robot.
abstract final class AppTheme {
  static ThemeData dark() {
    final base = ThemeData(brightness: Brightness.dark, useMaterial3: true);
    final textTheme = GoogleFonts.jetBrainsMonoTextTheme(base.textTheme).apply(
      bodyColor: AppColors.textPrimary,
      displayColor: AppColors.textPrimary,
    );
    final scheme = ColorScheme.dark(
      primary: AppColors.accent,
      onPrimary: AppColors.background,
      secondary: AppColors.success,
      onSecondary: AppColors.background,
      surface: AppColors.surface,
      onSurface: AppColors.textPrimary,
      error: AppColors.danger,
    );

    return base.copyWith(
      scaffoldBackgroundColor: AppColors.background,
      canvasColor: AppColors.background,
      colorScheme: scheme,
      textTheme: textTheme,
      primaryTextTheme: textTheme,
      splashFactory: InkRipple.splashFactory,
      splashColor: AppColors.accent.withValues(alpha: 0.25),
      highlightColor: AppColors.accent.withValues(alpha: 0.08),
      dividerColor: AppColors.panelBorder,
      iconTheme: const IconThemeData(color: AppColors.accent),
      // Прямоугольные кнопки с обводкой; при нажатии — циановая заливка
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: AppColors.accent,
          side: const BorderSide(color: AppColors.accent),
          shape: const RoundedRectangleBorder(),
          textStyle: AppText.mono(
            size: 14,
            weight: FontWeight.w700,
            letterSpacing: 2,
          ),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        ).copyWith(
          overlayColor: WidgetStateProperty.resolveWith<Color?>(
            (states) => states.contains(WidgetState.pressed)
                ? AppColors.accent.withValues(alpha: 0.35)
                : null,
          ),
        ),
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: AppColors.surface,
        contentTextStyle: AppText.mono(size: 12),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          side: BorderSide(color: AppColors.panelBorder),
        ),
      ),
    );
  }
}
