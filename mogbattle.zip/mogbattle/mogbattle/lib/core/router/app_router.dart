import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/analysis/presentation/screens/analysis_screen.dart';
import '../../features/analysis/presentation/screens/neural_network_screen.dart';
import '../../features/history/presentation/screens/history_screen.dart';
import '../../features/home/presentation/screens/home_screen.dart';
import '../../features/opponent/presentation/screens/opponent_select_screen.dart';
import '../../features/upload/presentation/screens/upload_screen.dart';
import '../../features/verdict/presentation/screens/verdict_screen.dart';
import 'routes.dart';

/// Конфигурация go_router. Данные между экранами идут через Riverpod, не через extra.
final routerProvider = Provider<GoRouter>((ref) {
  final router = GoRouter(
    initialLocation: AppRoutes.home,
    routes: [
      _fadeRoute(AppRoutes.home, const HomeScreen()),
      _fadeRoute(AppRoutes.opponent, const OpponentSelectScreen()),
      _fadeRoute(AppRoutes.upload, const UploadScreen()),
      _fadeRoute(AppRoutes.analysis, const AnalysisScreen()),
      _fadeRoute(AppRoutes.neural, const NeuralNetworkScreen()),
      _fadeRoute(AppRoutes.verdict, const VerdictScreen()),
      _fadeRoute(AppRoutes.history, const HistoryScreen()),
    ],
  );
  ref.onDispose(router.dispose);
  return router;
});

/// Все переходы — плавный fade (кинематографично, без «материальных» слайдов).
GoRoute _fadeRoute(String path, Widget screen) {
  return GoRoute(
    path: path,
    pageBuilder: (context, state) => CustomTransitionPage<void>(
      key: state.pageKey,
      child: screen,
      transitionDuration: const Duration(milliseconds: 320),
      reverseTransitionDuration: const Duration(milliseconds: 220),
      transitionsBuilder: (context, animation, secondaryAnimation, child) =>
          FadeTransition(
        opacity: CurvedAnimation(parent: animation, curve: Curves.easeOut),
        child: child,
      ),
    ),
  );
}
