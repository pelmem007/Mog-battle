import 'package:flutter/widgets.dart';
import 'package:go_router/go_router.dart';

/// Пути экранов.
abstract final class AppRoutes {
  static const home = '/';
  static const opponent = '/opponent';
  static const upload = '/upload';
  static const analysis = '/analysis';
  static const neural = '/neural';
  static const verdict = '/verdict';
  static const history = '/history';
}

extension NavX on BuildContext {
  /// Назад; если стека нет — на главный экран.
  void popOrHome() {
    if (canPop()) {
      pop();
    } else {
      go(AppRoutes.home);
    }
  }
}
