import 'package:flutter/material.dart';

/// Мигающий индикатор (точка REC, курсор).
class Blink extends StatefulWidget {
  const Blink({
    super.key,
    required this.child,
    this.period = const Duration(milliseconds: 1000),
    this.minOpacity = 0.15,
  });

  final Widget child;
  final Duration period;
  final double minOpacity;

  @override
  State<Blink> createState() => _BlinkState();
}

class _BlinkState extends State<Blink> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: widget.period)
        ..repeat(reverse: true);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: Tween<double>(begin: widget.minOpacity, end: 1).animate(_c),
      child: widget.child,
    );
  }
}
