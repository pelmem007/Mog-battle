import 'package:flutter/material.dart';

import '../constants/colors.dart';
import '../constants/strings.dart';
import '../router/routes.dart';
import '../theme/app_theme.dart';
import 'blink.dart';
import 'noise_overlay.dart';
import 'scanline_overlay.dart';

/// Каркас экрана: фон + сетка, зерно, scanline и HUD-метки по углам.
class HudScaffold extends StatelessWidget {
  const HudScaffold({
    super.key,
    required this.child,
    this.title,
    this.showBack = false,
    this.onBack,
    this.leftLabel = AppStrings.hudSystemActive,
    this.rightLabel = AppStrings.hudRec,
    this.footerLabel,
    this.padding = const EdgeInsets.fromLTRB(20, 8, 20, 16),
  });

  final Widget child;
  final String? title;
  final bool showBack;
  final VoidCallback? onBack;
  final String leftLabel;
  final String rightLabel;
  final String? footerLabel;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        fit: StackFit.expand,
        children: [
          const _Backdrop(),
          const NoiseOverlay(),
          SafeArea(
            child: Column(
              children: [
                _HudBar(
                  showBack: showBack,
                  onBack: onBack,
                  leftLabel: leftLabel,
                  rightLabel: rightLabel,
                ),
                if (title != null) _TitleBlock(title: title!),
                Expanded(child: Padding(padding: padding, child: child)),
                if (footerLabel != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Text(
                      footerLabel!,
                      style: AppText.mono(
                        size: 10,
                        color: AppColors.textMuted,
                        letterSpacing: 1,
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const ScanlineOverlay(),
        ],
      ),
    );
  }
}

class _Backdrop extends StatelessWidget {
  const _Backdrop();

  @override
  Widget build(BuildContext context) {
    return const DecoratedBox(
      decoration: BoxDecoration(
        gradient: RadialGradient(
          center: Alignment(0, -0.5),
          radius: 1.15,
          colors: [Color(0xFF101A26), AppColors.background],
        ),
      ),
      child: CustomPaint(painter: _GridPainter()),
    );
  }
}

class _GridPainter extends CustomPainter {
  const _GridPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppColors.accent.withValues(alpha: 0.035)
      ..strokeWidth = 1;
    const step = 36.0;
    for (var x = 0.0; x <= size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (var y = 0.0; y <= size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _HudBar extends StatelessWidget {
  const _HudBar({
    required this.showBack,
    required this.onBack,
    required this.leftLabel,
    required this.rightLabel,
  });

  final bool showBack;
  final VoidCallback? onBack;
  final String leftLabel;
  final String rightLabel;

  @override
  Widget build(BuildContext context) {
    final style = AppText.mono(
      size: 10,
      color: AppColors.textMuted,
      letterSpacing: 1.2,
    );
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 6, 20, 0),
      child: Row(
        children: [
          if (showBack)
            IconButton(
              onPressed: onBack ?? () => context.popOrHome(),
              visualDensity: VisualDensity.compact,
              icon: const Icon(
                Icons.arrow_back_ios_new_rounded,
                size: 16,
                color: AppColors.accent,
              ),
            )
          else
            const SizedBox(width: 8, height: 40),
          Blink(
            child: Container(width: 6, height: 6, color: AppColors.success),
          ),
          const SizedBox(width: 6),
          Text(leftLabel, style: style),
          const Spacer(),
          Blink(
            period: const Duration(milliseconds: 800),
            child: Container(
              width: 8,
              height: 8,
              decoration: const BoxDecoration(
                color: AppColors.danger,
                shape: BoxShape.circle,
              ),
            ),
          ),
          const SizedBox(width: 6),
          Text(rightLabel, style: style.copyWith(color: AppColors.danger)),
        ],
      ),
    );
  }
}

class _TitleBlock extends StatelessWidget {
  const _TitleBlock({required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: AppText.mono(size: 22, weight: FontWeight.w700, letterSpacing: 2),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Container(width: 40, height: 2, color: AppColors.accent),
              Expanded(child: Container(height: 1, color: AppColors.panelBorder)),
            ],
          ),
        ],
      ),
    );
  }
}
