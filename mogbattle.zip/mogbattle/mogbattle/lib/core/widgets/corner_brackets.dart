import 'package:flutter/material.dart';

/// Угловые скобки по периметру (терминал / прицел).
class CornerBracketsPainter extends CustomPainter {
  const CornerBracketsPainter({
    required this.color,
    this.length = 12,
    this.strokeWidth = 1.5,
    this.inset = 0,
  });

  final Color color;
  final double length;
  final double strokeWidth;
  final double inset;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = strokeWidth
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.square;
    final l = inset, t = inset;
    final r = size.width - inset, b = size.height - inset;
    final path = Path()
      ..moveTo(l, t + length)
      ..lineTo(l, t)
      ..lineTo(l + length, t)
      ..moveTo(r - length, t)
      ..lineTo(r, t)
      ..lineTo(r, t + length)
      ..moveTo(r, b - length)
      ..lineTo(r, b)
      ..lineTo(r - length, b)
      ..moveTo(l + length, b)
      ..lineTo(l, b)
      ..lineTo(l, b - length);
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CornerBracketsPainter old) =>
      old.color != color ||
      old.length != length ||
      old.strokeWidth != strokeWidth ||
      old.inset != inset;
}
