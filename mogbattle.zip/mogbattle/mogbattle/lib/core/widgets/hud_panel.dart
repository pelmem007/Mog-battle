import 'package:flutter/material.dart';

import '../constants/colors.dart';
import 'corner_brackets.dart';

/// Полупрозрачная панель: тонкая обводка (1px, opacity 0.3) + угловые скобки.
class HudPanel extends StatelessWidget {
  const HudPanel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.accent = AppColors.accent,
    this.fillColor,
    this.glow = false,
    this.onTap,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;

  /// Цвет обводки и скобок (циан / красный / золото).
  final Color accent;
  final Color? fillColor;
  final bool glow;

  /// Если задан — панель кликабельна, при нажатии циановый ripple.
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        boxShadow: glow
            ? [BoxShadow(color: accent.withValues(alpha: 0.28), blurRadius: 18)]
            : null,
      ),
      child: CustomPaint(
        foregroundPainter: CornerBracketsPainter(
          color: accent,
          length: 10,
          strokeWidth: 1.5,
        ),
        child: Material(
          type: MaterialType.transparency,
          child: Ink(
            decoration: BoxDecoration(
              color: fillColor ?? AppColors.panelFill,
              border: Border.all(color: accent.withValues(alpha: 0.3)),
            ),
            child: InkWell(
              onTap: onTap,
              splashColor: accent.withValues(alpha: 0.28),
              highlightColor: accent.withValues(alpha: 0.10),
              child: Padding(padding: padding, child: child),
            ),
          ),
        ),
      ),
    );
  }
}
