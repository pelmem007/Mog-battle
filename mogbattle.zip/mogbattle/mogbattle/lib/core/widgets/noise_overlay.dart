import 'dart:async';
import 'dart:math';
import 'dart:typed_data' show Float32List;
import 'dart:ui' show PointMode;

import 'package:flutter/foundation.dart' show ValueListenable;
import 'package:flutter/material.dart';

/// Лёгкое «зерно» поверх экрана (CustomPainter, opacity ≈ 0.03).
class NoiseOverlay extends StatefulWidget {
  const NoiseOverlay({super.key, this.opacity = 0.03, this.fps = 12});

  final double opacity;
  final int fps;

  @override
  State<NoiseOverlay> createState() => _NoiseOverlayState();
}

class _NoiseOverlayState extends State<NoiseOverlay> {
  final _tick = ValueNotifier<int>(0);
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    // Перерисовываем с новым сидом ~12 раз в секунду — зерно «живое»
    _timer = Timer.periodic(
      Duration(milliseconds: (1000 / widget.fps).round()),
      (_) => _tick.value++,
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _tick.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: RepaintBoundary(
        child: CustomPaint(
          size: Size.infinite,
          painter: NoisePainter(tick: _tick, opacity: widget.opacity),
        ),
      ),
    );
  }
}

class NoisePainter extends CustomPainter {
  NoisePainter({required this.tick, required this.opacity})
      : super(repaint: tick);

  final ValueListenable<int> tick;
  final double opacity;

  @override
  void paint(Canvas canvas, Size size) {
    final rng = Random(tick.value * 7919 + 13);
    final count = (size.width * size.height / 90).round();
    final pts = Float32List(count * 2);
    for (var i = 0; i < pts.length; i += 2) {
      pts[i] = rng.nextDouble() * size.width;
      pts[i + 1] = rng.nextDouble() * size.height;
    }
    final paint = Paint()
      ..color = Colors.white.withValues(alpha: opacity)
      ..strokeWidth = 1.5
      ..strokeCap = StrokeCap.square;
    canvas.drawRawPoints(PointMode.points, pts, paint);
  }

  @override
  bool shouldRepaint(NoisePainter old) => old.opacity != opacity;
}
