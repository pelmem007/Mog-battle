import 'package:flutter/material.dart';

/// Палитра Mr. Robot.
abstract final class AppColors {
  static const background = Color(0xFF0A0E14);
  static const surface = Color(0xFF111820);
  static const accent = Color(0xFF00E5FF); // циан
  static const success = Color(0xFF00FF9C); // ты
  static const danger = Color(0xFFFF3B5C); // соперник
  static const gold = Color(0xFFFFD166); // победитель
  static const textPrimary = Color(0xFFE6EDF3);
  static const textMuted = Color(0xFF6E7681);

  /// Тонкая циановая обводка панелей (1px, opacity 0.3).
  static Color get panelBorder => accent.withValues(alpha: 0.3);

  /// Полупрозрачная заливка панелей.
  static Color get panelFill => surface.withValues(alpha: 0.72);
}
