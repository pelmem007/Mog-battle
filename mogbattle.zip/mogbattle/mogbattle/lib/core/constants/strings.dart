/// Все тексты интерфейса в одном месте.
abstract final class AppStrings {
  // ── Общее ──
  static const appName = 'MogBattle';
  static const versionLine = 'v4.2.1 // NEURAL CORE ACTIVE';
  static const watermark = 'MogBattle v4.2';
  static const disclaimer = '// FOR ENTERTAINMENT PURPOSES ONLY';

  // ── HUD ──
  static const hudSystemActive = '// SYSTEM ACTIVE';
  static const hudRec = '[REC]';

  // ── Home / профиль (захардкожено) ──
  static const nickname = 'USER_7X';
  static const mogRating = '96.8';
  static const totalMogs = '47';
  static const winRate = '100.0%';
  static const rank = 'GIGACHAD';
  static const lastBattle = '2 hours ago';
  static const initiateBattle = 'INITIATE MOG BATTLE';

  // ── Opponent select ──
  static const selectOpponent = 'SELECT OPPONENT';
  static const opponentTypes = <String>[
    'MODEL',
    'ACTOR',
    'INFLUENCER',
    'CUSTOM PHOTO',
  ];

  // ── Upload ──
  static const uploadTitle = 'LOAD TARGETS';
  static const slotYou = 'YOU';
  static const slotOpponent = 'OPPONENT';
  static const initiateScan = 'INITIATE SCAN';

  // ── Analysis: строки терминала ──
  static const terminalLines = <String>[
    'Initializing neural core v4.2.1...',
    'Loading face_recognition.tflite [OK]',
    'Extracting 512-d face embeddings...',
    'Running symmetry matrix...',
    'Analyzing jawline curvature...',
    'Measuring canthal tilt...',
    'Computing facial harmony index...',
    'Cross-referencing 2.4M reference faces...',
    'Generating verdict...',
  ];

  // ── Neural network ──
  static const neuralProcessing = 'PROCESSING 128-DIMENSIONAL FACE EMBEDDING...';
  static const neuralComplete = 'ANALYSIS COMPLETE. CONFIDENCE: 99.7%';

  // ── Verdict ──
  static const mogger = 'MOGGER';
  static const mogged = 'MOGGED';
  static const mogGap = 'MOG GAP';
  static const shareToTiktok = 'SHARE TO TIKTOK';
  static const scanAgain = 'SCAN AGAIN';
  static const viewHistory = 'VIEW HISTORY';

  // ── History ──
  static const historyTitle = 'BATTLE HISTORY';
  static const historyEmpty = '// NO BATTLES RECORDED';
}
