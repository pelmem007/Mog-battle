/// Описание одной метрики.
class MetricDef {
  const MetricDef({
    required this.id,
    required this.label,
    this.isOverall = false,
  });

  final String id;
  final String label;

  /// Итоговая строка: считается как среднее по остальным метрикам.
  final bool isOverall;
}

/// 8 метрик и диапазоны значений.
abstract final class MetricsData {
  static const double youMin = 89.0;
  static const double youMax = 98.0;
  static const double oppMin = 62.0;
  static const double oppMax = 78.0;

  /// Шанс, что одна метрика достанется сопернику.
  static const double invertChance = 0.20;

  static const List<MetricDef> all = [
    MetricDef(id: 'symmetry', label: 'FACIAL SYMMETRY'),
    MetricDef(id: 'jawline', label: 'JAWLINE DEFINITION'),
    MetricDef(id: 'canthal', label: 'CANTHAL TILT'),
    MetricDef(id: 'midface', label: 'MIDFACE RATIO'),
    MetricDef(id: 'harmony', label: 'FACIAL HARMONY INDEX'),
    MetricDef(id: 'skin', label: 'SKIN CLARITY SCORE'),
    MetricDef(id: 'bone', label: 'BONE STRUCTURE DENSITY'),
    MetricDef(id: 'overall', label: 'OVERALL AESTHETICS', isOverall: true),
  ];
}
