import 'dart:math';

import '../../features/analysis/domain/models/face_analysis.dart';
import '../../features/analysis/domain/models/metric_result.dart';
import '../constants/metrics_data.dart';

/// Генератор фейковых метрик. Никакого ML: пользователь (первое фото) всегда побеждает.
class FakeAnalyzer {
  /// Сид — текущее время, чтобы каждый запуск отличался.
  FakeAnalyzer({Random? random})
      : _rng = random ?? Random(DateTime.now().millisecondsSinceEpoch);

  final Random _rng;

  double _range(double min, double max) => min + _rng.nextDouble() * (max - min);

  /// Округление до 1 знака.
  static double round1(double v) => (v * 10).round() / 10;

  /// 8 метрик: 7 базовых + OVERALL AESTHETICS (среднее по базовым),
  /// поэтому итог на экране анализа совпадает с вердиктом.
  List<MetricResult> generateMetrics() {
    final defs = MetricsData.all.where((d) => !d.isOverall).toList();

    // С шансом 20% одна случайная метрика уходит сопернику
    final flipped = _rng.nextDouble() < MetricsData.invertChance
        ? _rng.nextInt(defs.length)
        : -1;

    final results = <MetricResult>[];
    for (var i = 0; i < defs.length; i++) {
      final d = defs[i];
      if (i == flipped) {
        // Инверсия: соперник выше на 1.5–6 п. Не полный swap — так правдоподобнее
        final opp = round1(_range(MetricsData.youMin, MetricsData.youMax - 3));
        final you = round1(opp - _range(1.5, 6.0));
        results.add(MetricResult(
          id: d.id,
          label: d.label,
          you: you,
          opp: opp,
          opponentWins: true,
        ));
      } else {
        results.add(MetricResult(
          id: d.id,
          label: d.label,
          you: round1(_range(MetricsData.youMin, MetricsData.youMax)),
          opp: round1(_range(MetricsData.oppMin, MetricsData.oppMax)),
        ));
      }
    }

    double avg(double Function(MetricResult) pick) =>
        round1(results.fold<double>(0, (s, m) => s + pick(m)) / results.length);

    final overall = MetricsData.all.firstWhere((d) => d.isOverall);
    results.add(MetricResult(
      id: overall.id,
      label: overall.label,
      you: avg((m) => m.you),
      opp: avg((m) => m.opp),
      isOverall: true,
    ));
    return results;
  }

  /// Метрики + итоговые баллы и gap.
  FaceAnalysis analyze() {
    final metrics = generateMetrics();
    final overall = metrics.last;
    // Даже при худшей инверсии среднее you ≥ ~88, opp ≤ ~80.5 — gap всегда > 0
    final gap = round1(overall.you - overall.opp);
    assert(gap > 0, 'Пользователь обязан побеждать');
    return FaceAnalysis(
      metrics: metrics,
      youScore: overall.you,
      oppScore: overall.opp,
      gap: gap,
    );
  }
}
