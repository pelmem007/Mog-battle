import 'dart:io';

import 'package:flutter/foundation.dart' show debugPrint;
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';

/// Выбор фото из галереи.
class PhotoPicker {
  final _picker = ImagePicker();

  /// Возвращает файл или null, если пользователь отменил выбор.
  Future<File?> pickFromGallery() async {
    try {
      // Системный пикер работает и без разрешения, поэтому отказ не блокирует выбор
      final status = await Permission.photos.status;
      if (!status.isGranted && !status.isPermanentlyDenied) {
        await Permission.photos.request();
      }
      final x = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 2048, // меньше кадр — быстрее детекция
        maxHeight: 2048,
        imageQuality: 92,
      );
      return x == null ? null : File(x.path);
    } catch (e) {
      debugPrint('PhotoPicker: $e');
      return null;
    }
  }
}
