import 'dart:io';
import 'dart:isolate';
import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/foundation.dart' show debugPrint;
import 'package:flutter/services.dart' show rootBundle;
import 'package:opencv_dart/opencv_dart.dart' as cv;
import 'package:path_provider/path_provider.dart';

/// Результат сканирования одного фото.
class FaceScan {
  const FaceScan({
    required this.imageSize,
    required this.faceRect,
    required this.landmarks,
    required this.detected,
  });

  /// Размер изображения в пикселях (с учётом EXIF-поворота).
  final Size imageSize;

  /// Bounding box лица в пикселях изображения.
  final Rect faceRect;

  /// leftEye, rightEye, nose, mouth — в пикселях изображения.
  final Map<String, Offset> landmarks;

  /// false — лицо не найдено, использован центр кадра.
  final bool detected;

  /// Пиксели изображения → координаты виджета при BoxFit.cover (по центру).
  Offset toView(Offset p, Size view) {
    final s = math.max(
      view.width / imageSize.width,
      view.height / imageSize.height,
    );
    final dx = (view.width - imageSize.width * s) / 2;
    final dy = (view.height - imageSize.height * s) / 2;
    return Offset(p.dx * s + dx, p.dy * s + dy);
  }

  Rect rectToView(Rect r, Size view) =>
      Rect.fromPoints(toView(r.topLeft, view), toView(r.bottomRight, view));
}

/// Обёртка над opencv_dart: только Haar Cascade детекция лица.
class FaceDetector {
  FaceDetector._();
  static final FaceDetector instance = FaceDetector._();

  static const _asset = 'assets/haarcascade_frontalface_default.xml';

  // Пропорции ориентиров внутри bounding box: (доля высоты, доля ширины)
  static const _leftEye = (0.30, 0.25);
  static const _rightEye = (0.30, 0.75);
  static const _nose = (0.50, 0.50);
  static const _mouth = (0.75, 0.50);

  String? _cascadePath;
  Future<void>? _init;

  /// OpenCV грузит каскад только с диска — копируем из assets во временный файл.
  Future<void> init() => _init ??= _prepareCascade();

  Future<void> _prepareCascade() async {
    try {
      final data = await rootBundle.load(_asset);
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/haarcascade_frontalface_default.xml');
      await file.writeAsBytes(
        data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
        flush: true,
      );
      _cascadePath = file.path;
    } catch (e) {
      debugPrint('FaceDetector: каскад недоступен: $e');
    }
  }

  /// Bounding box'ы лиц в пикселях изображения, самое крупное — первым.
  Future<List<Rect>> detectFaces(File image) async => (await _detect(image)).faces;

  /// Точки глаз, носа и рта по пропорциям bounding box.
  Map<String, Offset> getLandmarks(Rect faceRect) {
    Offset at((double, double) p) => Offset(
          faceRect.left + faceRect.width * p.$2,
          faceRect.top + faceRect.height * p.$1,
        );
    return {
      'leftEye': at(_leftEye),
      'rightEye': at(_rightEye),
      'nose': at(_nose),
      'mouth': at(_mouth),
    };
  }

  /// Полный скан: размер кадра + лицо + ориентиры.
  /// Лицо не найдено — fallback: центр изображения.
  Future<FaceScan> scan(File image) async {
    final det = await _detect(image);
    var size = det.size;
    if (size.isEmpty) size = await _flutterImageSize(image);
    if (size.isEmpty) size = const Size(1080, 1080);

    final detected = det.faces.isNotEmpty;
    final rect = detected ? det.faces.first : _fallbackRect(size);
    return FaceScan(
      imageSize: size,
      faceRect: rect,
      landmarks: getLandmarks(rect),
      detected: detected,
    );
  }

  Rect _fallbackRect(Size size) {
    final side = math.min(size.width, size.height) * 0.55;
    return Rect.fromCenter(
      center: size.center(Offset.zero),
      width: side,
      height: side * 1.2,
    );
  }

  Future<_Detection> _detect(File image) async {
    await init();
    final cascade = _cascadePath;
    if (cascade == null) return const _Detection(Size.zero, []);
    try {
      final res = await _runInIsolate(_DetectRequest(image.path, cascade));
      final faces = [
        for (final r in res.rects) Rect.fromLTWH(r[0], r[1], r[2], r[3]),
      ];
      return _Detection(Size(res.width.toDouble(), res.height.toDouble()), faces);
    } catch (e) {
      debugPrint('FaceDetector: ошибка детекции: $e');
      return const _Detection(Size.zero, []);
    }
  }

  // Статический метод — замыкание не тянет за собой this
  static Future<_DetectResponse> _runInIsolate(_DetectRequest req) =>
      Isolate.run(() => _detectInIsolate(req));

  /// Размер через Flutter — на случай, если OpenCV не прочитал файл (например HEIC).
  Future<Size> _flutterImageSize(File file) async {
    try {
      final buffer = await ImmutableBuffer.fromUint8List(await file.readAsBytes());
      try {
        final desc = await ImageDescriptor.encoded(buffer);
        final s = Size(desc.width.toDouble(), desc.height.toDouble());
        desc.dispose();
        return s;
      } finally {
        buffer.dispose();
      }
    } catch (_) {
      return Size.zero;
    }
  }
}

class _Detection {
  const _Detection(this.size, this.faces);
  final Size size;
  final List<Rect> faces;
}

// ── Работа в отдельном изоляте: через границу ходят только примитивы ──

class _DetectRequest {
  const _DetectRequest(this.imagePath, this.cascadePath);
  final String imagePath;
  final String cascadePath;
}

class _DetectResponse {
  const _DetectResponse(this.width, this.height, this.rects);
  final int width;
  final int height;

  /// [left, top, width, height] в пикселях оригинала.
  final List<List<double>> rects;
}

/// Длинная сторона кадра для детекции (ускоряет Haar на больших фото).
const int _maxSide = 800;

_DetectResponse _detectInIsolate(_DetectRequest req) {
  final classifier = cv.CascadeClassifier.empty();
  cv.Mat? src;
  cv.Mat? resized;
  cv.Mat? eq;
  try {
    if (!classifier.load(req.cascadePath)) {
      return const _DetectResponse(0, 0, []);
    }
    src = cv.imread(req.imagePath, flags: cv.IMREAD_GRAYSCALE);
    if (src.isEmpty) return const _DetectResponse(0, 0, []);

    final w = src.cols;
    final h = src.rows;
    final scale = math.min(1.0, _maxSide / math.max(w, h));
    if (scale < 1.0) {
      resized = cv.resize(
        src,
        ((w * scale).round(), (h * scale).round()),
        interpolation: cv.INTER_AREA,
      );
    }
    final base = resized ?? src;
    eq = cv.equalizeHist(base);

    final minFace = math.max(
      24,
      math.min(400, (math.min(base.cols, base.rows) * 0.15).round()),
    );
    final found = classifier.detectMultiScale(
      eq,
      scaleFactor: 1.1,
      minNeighbors: 5,
      minSize: (minFace, minFace),
    );

    final rects = <List<double>>[];
    for (var i = 0; i < found.length; i++) {
      final r = found[i];
      rects.add([r.x / scale, r.y / scale, r.width / scale, r.height / scale]);
    }
    rects.sort((a, b) => (b[2] * b[3]).compareTo(a[2] * a[3]));
    return _DetectResponse(w, h, rects);
  } finally {
    eq?.dispose();
    resized?.dispose();
    src?.dispose();
    classifier.dispose();
  }
}
