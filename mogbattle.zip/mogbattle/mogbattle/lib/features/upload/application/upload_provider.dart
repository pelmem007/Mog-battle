import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/utils/photo_picker.dart';

final photoPickerProvider = Provider<PhotoPicker>((ref) => PhotoPicker());

/// Два выбранных фото: первое — пользователь, второе — соперник.
class UploadState {
  const UploadState({this.you, this.opponent});

  final File? you;
  final File? opponent;

  bool get ready => you != null && opponent != null;

  UploadState copyWith({File? you, File? opponent}) =>
      UploadState(you: you ?? this.you, opponent: opponent ?? this.opponent);
}

class UploadNotifier extends Notifier<UploadState> {
  @override
  UploadState build() => const UploadState();

  /// true — фото выбрано.
  Future<bool> pickYou() async {
    final f = await ref.read(photoPickerProvider).pickFromGallery();
    if (f == null) return false;
    state = state.copyWith(you: f);
    return true;
  }

  Future<bool> pickOpponent() async {
    final f = await ref.read(photoPickerProvider).pickFromGallery();
    if (f == null) return false;
    state = state.copyWith(opponent: f);
    return true;
  }

  void reset() => state = const UploadState();
}

final uploadProvider =
    NotifierProvider<UploadNotifier, UploadState>(UploadNotifier.new);
