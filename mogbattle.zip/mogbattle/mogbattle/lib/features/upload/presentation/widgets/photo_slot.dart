import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../../core/constants/colors.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/widgets/hud_panel.dart';

/// Квадратный слот фото с подписью сверху.
class PhotoSlot extends StatelessWidget {
  const PhotoSlot({
    super.key,
    required this.label,
    required this.color,
    required this.file,
    required this.onTap,
  });

  final String label;
  final Color color;
  final File? file;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(width: 6, height: 6, color: color),
            const SizedBox(width: 8),
            Text(
              label,
              style: AppText.mono(
                size: 14,
                weight: FontWeight.w800,
                color: color,
                letterSpacing: 3,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        AspectRatio(
          aspectRatio: 1,
          child: HudPanel(
            accent: color,
            padding: const EdgeInsets.all(4),
            glow: file != null,
            onTap: () {
              HapticFeedback.selectionClick();
              onTap();
            },
            child: file == null ? _Empty(color: color) : _Filled(file: file!),
          ),
        ),
      ],
    );
  }
}

class _Empty extends StatelessWidget {
  const _Empty({required this.color});

  final Color color;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.add_a_photo_outlined, size: 32, color: color.withValues(alpha: 0.8)),
          const SizedBox(height: 10),
          Text(
            'TAP TO LOAD',
            style: AppText.mono(size: 10, color: AppColors.textMuted, letterSpacing: 1.5),
          ),
        ],
      ),
    );
  }
}

class _Filled extends StatelessWidget {
  const _Filled({required this.file});

  final File file;

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Image.file(file, fit: BoxFit.cover, cacheWidth: 600),
        Positioned(
          left: 0,
          right: 0,
          bottom: 0,
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 4),
            color: Colors.black54,
            child: Text(
              'TAP TO REPLACE',
              textAlign: TextAlign.center,
              style: AppText.mono(size: 8, color: AppColors.textMuted, letterSpacing: 1.2),
            ),
          ),
        ),
      ],
    );
  }
}
