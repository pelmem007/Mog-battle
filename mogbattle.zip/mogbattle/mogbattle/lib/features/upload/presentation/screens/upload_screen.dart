import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/colors.dart';
import '../../../../core/constants/strings.dart';
import '../../../../core/router/routes.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/widgets/hud_scaffold.dart';
import '../../../home/presentation/widgets/glow_button.dart';
import '../../application/upload_provider.dart';
import '../widgets/photo_slot.dart';

/// Экран 3: два слота фото. Когда оба заполнены — появляется INITIATE SCAN.
class UploadScreen extends ConsumerWidget {
  const UploadScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(uploadProvider);
    final n = ref.read(uploadProvider.notifier);
    final loaded = (s.you != null ? 1 : 0) + (s.opponent != null ? 1 : 0);

    return HudScaffold(
      title: AppStrings.uploadTitle,
      showBack: true,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: 28),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: PhotoSlot(
                  label: AppStrings.slotYou,
                  color: AppColors.accent,
                  file: s.you,
                  onTap: n.pickYou,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: PhotoSlot(
                  label: AppStrings.slotOpponent,
                  color: AppColors.danger,
                  file: s.opponent,
                  onTap: n.pickOpponent,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Center(
            child: Text(
              '// TARGETS LOADED: $loaded/2',
              style: AppText.mono(size: 11, color: AppColors.textMuted, letterSpacing: 1.5),
            ),
          ),
          const Spacer(),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 350),
            transitionBuilder: (child, anim) => FadeTransition(
              opacity: anim,
              child: SizeTransition(sizeFactor: anim, child: child),
            ),
            child: s.ready
                ? GlowButton(
                    key: const ValueKey('scan'),
                    label: AppStrings.initiateScan,
                    icon: Icons.center_focus_strong_rounded,
                    onPressed: () => context.push(AppRoutes.analysis),
                  )
                : const SizedBox.shrink(key: ValueKey('none')),
          ),
        ],
      ),
    );
  }
}
