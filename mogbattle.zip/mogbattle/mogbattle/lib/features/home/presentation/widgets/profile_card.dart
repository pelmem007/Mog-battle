import 'package:flutter/material.dart';

import '../../../../core/constants/colors.dart';
import '../../../../core/constants/strings.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/widgets/hud_panel.dart';

/// Карточка профиля: градиентный аватар с инициалами, ник, ранг.
class ProfileCard extends StatelessWidget {
  const ProfileCard({super.key});

  @override
  Widget build(BuildContext context) {
    return HudPanel(
      glow: true,
      child: Row(
        children: [
          const _Avatar(initials: 'U7'),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  AppStrings.nickname,
                  style: AppText.mono(size: 20, weight: FontWeight.w800, letterSpacing: 1.5),
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    border: Border.all(color: AppColors.gold),
                    color: AppColors.gold.withValues(alpha: 0.1),
                  ),
                  child: Text(
                    AppStrings.rank,
                    style: AppText.mono(
                      size: 11,
                      weight: FontWeight.w700,
                      color: AppColors.gold,
                      letterSpacing: 2,
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'LAST BATTLE: ${AppStrings.lastBattle}',
                  style: AppText.mono(size: 10, color: AppColors.textMuted, letterSpacing: 0.8),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Avatar extends StatelessWidget {
  const _Avatar({required this.initials});

  final String initials;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 68,
      height: 68,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.accent, AppColors.success],
        ),
        boxShadow: [
          BoxShadow(color: AppColors.accent.withValues(alpha: 0.4), blurRadius: 16),
        ],
      ),
      child: Text(
        initials,
        style: AppText.mono(size: 24, weight: FontWeight.w800, color: AppColors.background),
      ),
    );
  }
}
