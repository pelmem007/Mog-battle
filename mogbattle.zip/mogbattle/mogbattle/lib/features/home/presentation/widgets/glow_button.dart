import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../../core/constants/colors.dart';
import '../../../../core/theme/app_theme.dart';

/// Прямоугольная кнопка с обводкой и свечением. При нажатии — заливка цветом + ripple.
class GlowButton extends StatefulWidget {
  const GlowButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.color = AppColors.accent,
    this.icon,
    this.compact = false,
  });

  final String label;

  /// null — кнопка неактивна.
  final VoidCallback? onPressed;
  final Color color;
  final IconData? icon;
  final bool compact;

  @override
  State<GlowButton> createState() => _GlowButtonState();
}

class _GlowButtonState extends State<GlowButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    final enabled = widget.onPressed != null;
    final c = enabled ? widget.color : AppColors.textMuted;
    final fg = _down ? AppColors.background : c;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 120),
      decoration: BoxDecoration(
        color: _down ? c : c.withValues(alpha: 0.06),
        border: Border.all(color: c, width: 1.5),
        boxShadow: enabled
            ? [
                BoxShadow(
                  color: c.withValues(alpha: _down ? 0.6 : 0.3),
                  blurRadius: _down ? 28 : 18,
                ),
              ]
            : null,
      ),
      child: Material(
        type: MaterialType.transparency,
        child: InkWell(
          onTap: enabled
              ? () {
                  HapticFeedback.mediumImpact();
                  widget.onPressed!();
                }
              : null,
          onHighlightChanged: (v) => setState(() => _down = v),
          splashColor: Colors.white24,
          highlightColor: Colors.transparent,
          child: Padding(
            padding: EdgeInsets.symmetric(
              vertical: widget.compact ? 12 : 18,
              horizontal: 16,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (widget.icon != null) ...[
                  Icon(widget.icon, size: 18, color: fg),
                  const SizedBox(width: 10),
                ],
                Flexible(
                  child: Text(
                    widget.label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: AppText.mono(
                      size: widget.compact ? 12 : 15,
                      weight: FontWeight.w700,
                      letterSpacing: 2.5,
                      color: fg,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
