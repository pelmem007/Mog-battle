import 'package:flutter/material.dart';

import '../../../../core/constants/colors.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/widgets/hud_panel.dart';

/// Плитка статистики. Числовые значения «накручиваются» от 0 при появлении.
class StatTile extends StatelessWidget {
  const StatTile.number({
    super.key,
    required this.label,
    required double this.target,
    this.decimals = 0,
    this.suffix = '',
    this.color = AppColors.textPrimary,
  }) : text = null;

  const StatTile.text({
    super.key,
    required this.label,
    required String this.text,
    this.color = AppColors.textPrimary,
  })  : target = null,
        decimals = 0,
        suffix = '';

  final String label;
  final double? target;
  final int decimals;
  final String suffix;
  final String? text;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final valueStyle = AppText.mono(size: 24, weight: FontWeight.w800, color: color);
    return HudPanel(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: AppText.mono(
              size: 10,
              color: AppColors.textMuted,
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 8),
          if (target != null)
            TweenAnimationBuilder<double>(
              tween: Tween(begin: 0, end: target),
              duration: const Duration(milliseconds: 1300),
              curve: Curves.easeOutCubic,
              builder: (context, v, _) => Text(
                '${v.toStringAsFixed(decimals)}$suffix',
                style: valueStyle,
              ),
            )
          else
            FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerLeft,
              child: Text(text!, style: valueStyle),
            ),
        ],
      ),
    );
  }
}
