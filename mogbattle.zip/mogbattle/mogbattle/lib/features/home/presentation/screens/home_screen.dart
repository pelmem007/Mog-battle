import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/colors.dart';
import '../../../../core/constants/strings.dart';
import '../../../../core/router/routes.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/widgets/hud_scaffold.dart';
import '../../../upload/application/upload_provider.dart';
import '../widgets/glow_button.dart';
import '../widgets/profile_card.dart';
import '../widgets/stat_tile.dart';

/// Экран 1: профиль с захардкоженной статистикой.
class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return HudScaffold(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.only(top: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    AppStrings.appName.toUpperCase(),
                    style: AppText.mono(
                      size: 12,
                      color: AppColors.accent,
                      letterSpacing: 6,
                      weight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 14),
                  const ProfileCard(),
                  const SizedBox(height: 14),
                  const Row(
                    children: [
                      Expanded(
                        child: StatTile.number(
                          label: 'MOG RATING',
                          target: 96.8,
                          decimals: 1,
                          color: AppColors.success,
                        ),
                      ),
                      SizedBox(width: 14),
                      Expanded(
                        child: StatTile.number(label: 'TOTAL MOGS', target: 47),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  const Row(
                    children: [
                      Expanded(
                        child: StatTile.number(
                          label: 'WIN RATE',
                          target: 100,
                          decimals: 1,
                          suffix: '%',
                          color: AppColors.success,
                        ),
                      ),
                      SizedBox(width: 14),
                      Expanded(
                        child: StatTile.text(
                          label: 'RANK',
                          text: AppStrings.rank,
                          color: AppColors.gold,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          GlowButton(
            label: AppStrings.initiateBattle,
            icon: Icons.bolt_rounded,
            onPressed: () {
              ref.read(uploadProvider.notifier).reset();
              context.push(AppRoutes.opponent);
            },
          ),
          const SizedBox(height: 8),
          TextButton(
            onPressed: () => context.push(AppRoutes.history),
            child: Text(
              '// ${AppStrings.historyTitle}',
              style: AppText.mono(size: 11, color: AppColors.textMuted, letterSpacing: 1.5),
            ),
          ),
          Align(
            alignment: Alignment.centerRight,
            child: Text(
              AppStrings.versionLine,
              style: AppText.mono(size: 9, color: AppColors.textMuted),
            ),
          ),
          const SizedBox(height: 2),
          Align(
            alignment: Alignment.centerRight,
            child: Text(
              AppStrings.disclaimer,
              style: AppText.mono(size: 8, color: AppColors.textMuted.withValues(alpha: 0.6)),
            ),
          ),
        ],
      ),
    );
  }
}
