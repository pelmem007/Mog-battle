import 'dart:io';

import 'package:flutter/material.dart';

import '../../../../core/constants/colors.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/time_ago.dart';
import '../../../../core/widgets/hud_panel.dart';
import '../../data/models/battle_record.dart';

/// `[YOU 96.8] vs [OPP 71.2]  +25.6  2h ago` с миниатюрами.
class BattleListItem extends StatelessWidget {
  const BattleListItem({super.key, required this.record});

  final BattleRecord record;

  @override
  Widget build(BuildContext context) {
    return HudPanel(
      padding: const EdgeInsets.all(10),
      child: Row(
        children: [
          _Thumb(path: record.youPhotoPath, color: AppColors.success),
          const SizedBox(width: 8),
          _Thumb(path: record.oppPhotoPath, color: AppColors.danger, dim: true),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                FittedBox(
                  fit: BoxFit.scaleDown,
                  alignment: Alignment.centerLeft,
                  child: Text.rich(
                    TextSpan(
                      style: AppText.mono(size: 11),
                      children: [
                        TextSpan(
                          text: '[YOU ${record.youScore.toStringAsFixed(1)}]',
                          style: const TextStyle(color: AppColors.success),
                        ),
                        const TextSpan(text: ' vs '),
                        TextSpan(
                          text: '[OPP ${record.oppScore.toStringAsFixed(1)}]',
                          style: const TextStyle(color: AppColors.danger),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  timeAgo(record.createdAt),
                  style: AppText.mono(size: 10, color: AppColors.textMuted),
                ),
              ],
            ),
          ),
          Text(
            '+${record.gap.toStringAsFixed(1)}',
            style: AppText.mono(size: 18, weight: FontWeight.w800, color: AppColors.gold),
          ),
        ],
      ),
    );
  }
}

class _Thumb extends StatelessWidget {
  const _Thumb({required this.path, required this.color, this.dim = false});

  final String path;
  final Color color;
  final bool dim;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 48,
      height: 48,
      decoration: BoxDecoration(border: Border.all(color: color.withValues(alpha: 0.7))),
      child: Opacity(
        opacity: dim ? 0.55 : 1,
        child: Image.file(
          File(path),
          fit: BoxFit.cover,
          cacheWidth: 150,
          errorBuilder: (_, __, ___) => const Icon(
            Icons.broken_image_outlined,
            size: 20,
            color: AppColors.textMuted,
          ),
        ),
      ),
    );
  }
}
