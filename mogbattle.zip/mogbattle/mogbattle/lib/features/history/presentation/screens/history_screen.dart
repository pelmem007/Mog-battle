import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/colors.dart';
import '../../../../core/constants/strings.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/widgets/hud_scaffold.dart';
import '../../application/history_provider.dart';
import '../widgets/battle_list_item.dart';

/// Экран 7: история баттлов из Hive. Свайп — удалить запись.
class HistoryScreen extends ConsumerWidget {
  const HistoryScreen({super.key});

  Future<void> _confirmClear(BuildContext context, WidgetRef ref) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(side: BorderSide(color: AppColors.panelBorder)),
        title: Text('CLEAR HISTORY?', style: AppText.mono(size: 14, weight: FontWeight.w700)),
        content: Text(
          'All recorded battles will be deleted.',
          style: AppText.mono(size: 12, color: AppColors.textMuted),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text('CANCEL', style: AppText.mono(size: 12, color: AppColors.textMuted)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text('DELETE', style: AppText.mono(size: 12, color: AppColors.danger)),
          ),
        ],
      ),
    );
    if (ok == true) await ref.read(historyProvider.notifier).clear();
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final items = ref.watch(historyProvider);

    return HudScaffold(
      title: AppStrings.historyTitle,
      showBack: true,
      child: items.isEmpty
          ? Center(
              child: Text(
                AppStrings.historyEmpty,
                style: AppText.mono(size: 12, color: AppColors.textMuted, letterSpacing: 1.5),
              ),
            )
          : Column(
              children: [
                Expanded(
                  child: ListView.separated(
                    padding: const EdgeInsets.only(top: 16),
                    itemCount: items.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (context, i) {
                      final r = items[i];
                      return Dismissible(
                        key: ValueKey(r.id),
                        direction: DismissDirection.endToStart,
                        background: Container(
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.only(right: 20),
                          color: AppColors.danger.withValues(alpha: 0.25),
                          child: const Icon(Icons.delete_outline, color: AppColors.danger),
                        ),
                        onDismissed: (_) => ref.read(historyProvider.notifier).remove(r),
                        child: BattleListItem(record: r),
                      );
                    },
                  ),
                ),
                TextButton(
                  onPressed: () => _confirmClear(context, ref),
                  child: Text(
                    '// CLEAR HISTORY',
                    style: AppText.mono(size: 11, color: AppColors.textMuted, letterSpacing: 1.5),
                  ),
                ),
              ],
            ),
    );
  }
}
