import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/battle_repository.dart';
import '../data/models/battle_record.dart';

/// Подменяется в main.dart уже открытым репозиторием.
final battleRepositoryProvider = Provider<BattleRepository>(
  (ref) => throw UnimplementedError('battleRepositoryProvider не переопределён в main'),
);

class HistoryNotifier extends Notifier<List<BattleRecord>> {
  BattleRepository get _repo => ref.read(battleRepositoryProvider);

  @override
  List<BattleRecord> build() => _repo.all();

  Future<void> add({
    required File you,
    required File opponent,
    required double youScore,
    required double oppScore,
    required double gap,
  }) async {
    await _repo.add(
      you: you,
      opponent: opponent,
      youScore: youScore,
      oppScore: oppScore,
      gap: gap,
    );
    state = _repo.all();
  }

  Future<void> remove(BattleRecord r) async {
    await _repo.delete(r);
    state = _repo.all();
  }

  Future<void> clear() async {
    await _repo.clear();
    state = const [];
  }
}

final historyProvider =
    NotifierProvider<HistoryNotifier, List<BattleRecord>>(HistoryNotifier.new);
