import 'package:freezed_annotation/freezed_annotation.dart';

part 'battle_record.freezed.dart';
part 'battle_record.g.dart';

/// Запись об одном баттле (хранится в Hive как JSON).
@freezed
abstract class BattleRecord with _$BattleRecord {
  const factory BattleRecord({
    required String id,
    required String youPhotoPath,
    required String oppPhotoPath,
    required double youScore,
    required double oppScore,
    required double gap,
    required DateTime createdAt,
  }) = _BattleRecord;

  factory BattleRecord.fromJson(Map<String, dynamic> json) =>
      _$BattleRecordFromJson(json);
}
