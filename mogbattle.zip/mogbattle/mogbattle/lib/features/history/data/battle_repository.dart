import 'dart:convert';
import 'dart:io';

import 'package:hive_flutter/hive_flutter.dart';
import 'package:path_provider/path_provider.dart';

import 'models/battle_record.dart';

/// История баттлов в Hive: id → JSON-строка (без кодогенерации адаптеров).
class BattleRepository {
  BattleRepository._(this._box);

  final Box<String> _box;

  /// Вызывать после Hive.initFlutter().
  static Future<BattleRepository> open() async =>
      BattleRepository._(await Hive.openBox<String>('battles'));

  /// Новые сверху.
  List<BattleRecord> all() {
    final list = <BattleRecord>[];
    for (final raw in _box.values) {
      try {
        list.add(BattleRecord.fromJson(jsonDecode(raw) as Map<String, dynamic>));
      } catch (_) {
        // битую запись пропускаем
      }
    }
    list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return list;
  }

  /// Копирует фото в постоянную папку (кэш image_picker ОС может чистить).
  Future<BattleRecord> add({
    required File you,
    required File opponent,
    required double youScore,
    required double oppScore,
    required double gap,
  }) async {
    final id = DateTime.now().microsecondsSinceEpoch.toString();
    final base = await getApplicationDocumentsDirectory();
    final dir = Directory('${base.path}/battles');
    await dir.create(recursive: true);

    Future<String> keep(File f, String tag) async {
      try {
        final dot = f.path.lastIndexOf('.');
        final ext = dot > f.path.lastIndexOf('/') ? f.path.substring(dot) : '.jpg';
        return (await f.copy('${dir.path}/${id}_$tag$ext')).path;
      } catch (_) {
        return f.path;
      }
    }

    final record = BattleRecord(
      id: id,
      youPhotoPath: await keep(you, 'you'),
      oppPhotoPath: await keep(opponent, 'opp'),
      youScore: youScore,
      oppScore: oppScore,
      gap: gap,
      createdAt: DateTime.now(),
    );
    await _box.put(id, jsonEncode(record.toJson()));
    return record;
  }

  Future<void> delete(BattleRecord r) async {
    await _box.delete(r.id);
    for (final p in [r.youPhotoPath, r.oppPhotoPath]) {
      try {
        final f = File(p);
        if (p.contains('/battles/') && await f.exists()) await f.delete();
      } catch (_) {}
    }
  }

  Future<void> clear() async {
    for (final r in all()) {
      await delete(r);
    }
    await _box.clear();
  }
}
