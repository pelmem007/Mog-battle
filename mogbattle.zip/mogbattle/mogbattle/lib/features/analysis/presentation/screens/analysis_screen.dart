import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/colors.dart';
import '../../../../core/constants/strings.dart';
import '../../../../core/router/routes.dart';
import '../../../../core/widgets/hud_scaffold.dart';
import '../../../upload/application/upload_provider.dart';
import '../../application/analysis_provider.dart';
import '../widgets/metric_row.dart';
import '../widgets/scanning_face.dart';
import '../widgets/terminal_log.dart';

/// Экран 4: сканирование. Фото с рамками → терминал → 8 метрик → нейросеть.
class AnalysisScreen extends ConsumerStatefulWidget {
  const AnalysisScreen({super.key});

  @override
  ConsumerState<AnalysisScreen> createState() => _AnalysisScreenState();
}

class _AnalysisScreenState extends ConsumerState<AnalysisScreen> {
  final _rng = Random();
  final _scroll = ScrollController();
  final _lines = <String>[];
  int _metricsShown = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _run());
  }

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  /// Пауза; false — экран уже закрыт и сценарий надо прервать.
  Future<bool> _wait(int ms) async {
    await Future<void>.delayed(Duration(milliseconds: ms));
    return mounted;
  }

  void _scrollToEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scroll.hasClients) return;
      _scroll.animateTo(
        _scroll.position.maxScrollExtent,
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOut,
      );
    });
  }

  Future<void> _run() async {
    final up = ref.read(uploadProvider);
    if (!up.ready) {
      context.go(AppRoutes.upload);
      return;
    }
    final scanning =
        ref.read(analysisProvider.notifier).start(up.you!, up.opponent!);

    // 1) Терминал: строки с задержкой 400–800 мс
    for (final line in AppStrings.terminalLines) {
      if (!await _wait(400 + _rng.nextInt(401))) return;
      setState(() => _lines.add(line));
      _scrollToEnd();
    }
    await scanning;
    if (!mounted) return;

    // 2) Метрики по одной
    final metrics = ref.read(analysisProvider).analysis!.metrics;
    for (var i = 0; i < metrics.length; i++) {
      if (!await _wait(i == 0 ? 500 : 950)) return;
      setState(() => _metricsShown = i + 1);
      HapticFeedback.selectionClick();
      _scrollToEnd();
    }

    // 3) Пауза секунду и дальше — нейросеть
    if (!await _wait(1000)) return;
    context.pushReplacement(AppRoutes.neural);
  }

  @override
  Widget build(BuildContext context) {
    final up = ref.watch(uploadProvider);
    final an = ref.watch(analysisProvider);
    final metrics = an.analysis?.metrics ?? const [];

    if (!up.ready) return const HudScaffold(child: SizedBox.shrink());

    return PopScope(
      canPop: false, // во время скана назад нельзя
      child: HudScaffold(
        leftLabel: '// SCAN IN PROGRESS',
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: AspectRatio(
                    aspectRatio: 1,
                    child: ScanningFace(
                      file: up.you!,
                      scan: an.youScan,
                      label: AppStrings.slotYou,
                      color: AppColors.accent,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: AspectRatio(
                    aspectRatio: 1,
                    child: ScanningFace(
                      file: up.opponent!,
                      scan: an.oppScan,
                      label: AppStrings.slotOpponent,
                      color: AppColors.danger,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Expanded(
              child: SingleChildScrollView(
                controller: _scroll,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    TerminalLog(lines: _lines, active: _metricsShown == 0),
                    if (_metricsShown > 0) const SizedBox(height: 12),
                    for (var i = 0; i < _metricsShown && i < metrics.length; i++)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 6),
                        child: MetricRow(
                          key: ValueKey(metrics[i].id),
                          metric: metrics[i],
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
