import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/colors.dart';
import '../../../../core/constants/strings.dart';
import '../../../../core/router/routes.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/widgets/hud_scaffold.dart';
import '../widgets/neural_canvas.dart';

/// Экран 5: визуализация нейросети + прогресс до 100%, затем вердикт.
class NeuralNetworkScreen extends StatefulWidget {
  const NeuralNetworkScreen({super.key});

  @override
  State<NeuralNetworkScreen> createState() => _NeuralNetworkScreenState();
}

class _NeuralNetworkScreenState extends State<NeuralNetworkScreen> {
  final _rng = Random();
  Timer? _timer;
  Timer? _next;
  double _progress = 0; // 0–100
  double _jitter = 0; // подрагивание полосы
  bool _done = false;

  @override
  void initState() {
    super.initState();
    // Неравномерный набор процентов — ~7 секунд до 100
    _timer = Timer.periodic(const Duration(milliseconds: 60), (t) {
      if (!mounted) return;
      setState(() {
        _progress = min(100, _progress + 0.3 + _rng.nextDouble() * 1.1);
        _jitter = (_rng.nextDouble() - 0.5) * 0.012;
      });
      if (_progress >= 100) {
        t.cancel();
        HapticFeedback.heavyImpact();
        setState(() {
          _done = true;
          _jitter = 0;
        });
        _next = Timer(const Duration(milliseconds: 1200), () {
          if (mounted) context.pushReplacement(AppRoutes.verdict);
        });
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _next?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final frac = (_progress / 100 + _jitter).clamp(0.0, 1.0);
    return PopScope(
      canPop: false,
      child: HudScaffold(
        leftLabel: '// NEURAL CORE',
        child: Column(
          children: [
            const SizedBox(height: 8),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              child: Text(
                _done ? AppStrings.neuralComplete : AppStrings.neuralProcessing,
                key: ValueKey(_done),
                textAlign: TextAlign.center,
                style: AppText.mono(
                  size: 11,
                  weight: FontWeight.w700,
                  letterSpacing: 1.2,
                  color: _done ? AppColors.success : AppColors.accent,
                ),
              ),
            ),
            const SizedBox(height: 8),
            const Expanded(child: NeuralCanvas()),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: LayoutBuilder(
                    builder: (context, c) => Stack(
                      children: [
                        Container(height: 2, color: AppColors.panelBorder),
                        Container(
                          height: 2,
                          width: c.maxWidth * frac,
                          decoration: BoxDecoration(
                            color: _done ? AppColors.success : AppColors.accent,
                            boxShadow: [
                              BoxShadow(
                                color: (_done ? AppColors.success : AppColors.accent)
                                    .withValues(alpha: 0.7),
                                blurRadius: 8,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                SizedBox(
                  width: 44,
                  child: Text(
                    '${_progress.floor()}%',
                    textAlign: TextAlign.right,
                    style: AppText.mono(size: 12, weight: FontWeight.w700),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}
