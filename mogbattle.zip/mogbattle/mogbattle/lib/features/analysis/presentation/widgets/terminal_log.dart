import 'package:flutter/material.dart';

import '../../../../core/constants/colors.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/widgets/blink.dart';

/// Терминальный вывод: чёрный фон, зелёный текст, мигающий курсор.
class TerminalLog extends StatelessWidget {
  const TerminalLog({super.key, required this.lines, required this.active});

  final List<String> lines;

  /// true — на последней строке мигает курсор.
  final bool active;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xE6000000),
        border: Border.all(color: AppColors.success.withValues(alpha: 0.25)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'root@mogbattle:~# ./neural_core --scan',
            style: AppText.mono(size: 10, color: AppColors.success.withValues(alpha: 0.55)),
          ),
          const SizedBox(height: 6),
          for (var i = 0; i < lines.length; i++)
            _Line(text: lines[i], cursor: active && i == lines.length - 1),
        ],
      ),
    );
  }
}

class _Line extends StatelessWidget {
  const _Line({required this.text, required this.cursor});

  final String text;
  final bool cursor;

  @override
  Widget build(BuildContext context) {
    final base = AppText.mono(size: 11, color: AppColors.success, height: 1.45);
    final i = text.indexOf('[OK]');
    final span = i < 0
        ? TextSpan(text: '> $text', style: base)
        : TextSpan(
            style: base,
            children: [
              TextSpan(text: '> ${text.substring(0, i)}'),
              TextSpan(
                text: '[OK]',
                style: base.copyWith(
                  fontWeight: FontWeight.w800,
                  color: Colors.white,
                ),
              ),
            ],
          );
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Flexible(child: Text.rich(span)),
        if (cursor)
          Blink(
            period: const Duration(milliseconds: 500),
            child: Text(' █', style: base),
          ),
      ],
    );
  }
}
