import 'dart:math';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import '../../../../core/constants/colors.dart';

/// Слои сети: входы → два скрытых → выход.
const _layers = [8, 12, 12, 4];

/// Импульс, бегущий по связи слоя [layer] (узел [from] → узел [to] следующего слоя).
class _Pulse {
  _Pulse(this.layer, this.from, this.to, this.startMs, this.durMs);

  final int layer;
  final int from;
  final int to;
  final double startMs;
  final double durMs;
  bool chained = false;
}

class _NeuralModel extends ChangeNotifier {
  final pulses = <_Pulse>[];
  double nowMs = 0;

  void update(double ms) {
    nowMs = ms;
    notifyListeners();
  }
}

/// Анимация нейросети: пульсирующие узлы и светящиеся импульсы с затухающим шлейфом.
class NeuralCanvas extends StatefulWidget {
  const NeuralCanvas({super.key});

  @override
  State<NeuralCanvas> createState() => _NeuralCanvasState();
}

class _NeuralCanvasState extends State<NeuralCanvas>
    with SingleTickerProviderStateMixin {
  final _model = _NeuralModel();
  final _rng = Random();
  late final Ticker _ticker;
  Duration _last = Duration.zero;

  @override
  void initState() {
    super.initState();
    _ticker = createTicker(_onTick)..start();
  }

  _Pulse _spawn(int layer, int from, double ms) => _Pulse(
        layer,
        from,
        _rng.nextInt(_layers[layer + 1]),
        ms,
        400 + _rng.nextInt(401).toDouble(), // 400–800 мс
      );

  void _onTick(Duration d) {
    final ms = d.inMicroseconds / 1000.0;
    final dt = (d - _last).inMicroseconds / 1e6;
    _last = d;
    final pulses = _model.pulses;
    final fresh = <_Pulse>[];

    // Дошедший импульс продолжает путь в следующий слой
    for (final p in pulses) {
      if (!p.chained && ms - p.startMs >= p.durMs) {
        p.chained = true;
        if (p.layer + 1 < _layers.length - 1 && _rng.nextDouble() < 0.7) {
          fresh.add(_spawn(p.layer + 1, p.to, ms));
        }
      }
    }
    // Новые импульсы случайно, ~7 в секунду
    if (pulses.length < 70 && _rng.nextDouble() < dt * 7) {
      final layer = _rng.nextDouble() < 0.6 ? 0 : _rng.nextInt(_layers.length - 1);
      fresh.add(_spawn(layer, _rng.nextInt(_layers[layer]), ms));
    }
    pulses.addAll(fresh);
    // Живёт 1.4×длительности — последние 0.4 уходят на затухание шлейфа
    pulses.removeWhere((p) => ms - p.startMs > p.durMs * 1.4);
    _model.update(ms);
  }

  @override
  void dispose() {
    _ticker.dispose();
    _model.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: CustomPaint(size: Size.infinite, painter: _NeuralPainter(_model)),
    );
  }
}

class _NeuralPainter extends CustomPainter {
  _NeuralPainter(this.m) : super(repaint: m);

  final _NeuralModel m;

  Offset _pos(Size s, int l, int i) {
    const pad = 28.0;
    final x = pad + l * (s.width - 2 * pad) / (_layers.length - 1);
    final y = pad + (i + 0.5) * (s.height - 2 * pad) / _layers[l];
    return Offset(x, y);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final ms = m.nowMs;

    // ── Связи между соседними слоями (одним Path) ──
    final links = Path();
    for (var l = 0; l < _layers.length - 1; l++) {
      for (var i = 0; i < _layers[l]; i++) {
        for (var j = 0; j < _layers[l + 1]; j++) {
          links
            ..moveTo(_pos(size, l, i).dx, _pos(size, l, i).dy)
            ..lineTo(_pos(size, l + 1, j).dx, _pos(size, l + 1, j).dy);
        }
      }
    }
    canvas.drawPath(
      links,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = AppColors.accent.withValues(alpha: 0.09),
    );

    // ── Импульсы ──
    for (final p in m.pulses) {
      final t = (ms - p.startMs) / p.durMs;
      if (t < 0) continue;
      final head = t.clamp(0.0, 1.0);
      final tail = (t - 0.45).clamp(0.0, 1.0);
      final fade = t <= 1 ? 1.0 : (1 - (t - 1) / 0.4).clamp(0.0, 1.0);
      final a = _pos(size, p.layer, p.from);
      final b = _pos(size, p.layer + 1, p.to);
      final pTail = Offset.lerp(a, b, tail)!;
      final pHead = Offset.lerp(a, b, head)!;
      // цвет едет от циана к зелёному по мере продвижения вглубь сети
      final color = Color.lerp(
        AppColors.accent,
        AppColors.success,
        (p.layer + head) / (_layers.length - 1),
      )!;
      if ((pHead - pTail).distance > 0.5) {
        final shader = ui.Gradient.linear(
          pTail,
          pHead,
          [color.withValues(alpha: 0), color.withValues(alpha: fade)],
        );
        canvas.drawLine(
          pTail,
          pHead,
          Paint()
            ..shader = shader
            ..strokeWidth = 5
            ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
        );
        canvas.drawLine(
          pTail,
          pHead,
          Paint()
            ..shader = shader
            ..strokeWidth = 2,
        );
      }
      canvas.drawCircle(pHead, 3, Paint()..color = Colors.white.withValues(alpha: fade));
    }

    // ── Узлы: пульсация 0.8–1.2, цикл 1.5 с, сдвиг фазы по узлам ──
    for (var l = 0; l < _layers.length; l++) {
      final color = Color.lerp(
        AppColors.accent,
        AppColors.success,
        l / (_layers.length - 1),
      )!;
      for (var i = 0; i < _layers[l]; i++) {
        final phase = l * 0.9 + i * 0.55;
        final scale = 1 + 0.2 * sin(2 * pi * ms / 1500 + phase);
        final c = _pos(size, l, i);
        final r = 5 * scale;
        canvas.drawCircle(c, r * 2.1, Paint()..color = color.withValues(alpha: 0.12));
        canvas.drawCircle(c, r, Paint()..color = AppColors.background);
        canvas.drawCircle(
          c,
          r,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1.5
            ..color = color,
        );
        canvas.drawCircle(c, r * 0.45, Paint()..color = color);
      }
    }
  }

  @override
  bool shouldRepaint(_NeuralPainter old) => false;
}
