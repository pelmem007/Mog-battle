import 'package:flutter/material.dart';

import '../../../../core/constants/colors.dart';
import '../../../../core/theme/app_theme.dart';
import '../../domain/models/metric_result.dart';

/// Строка метрики: название слева, YOU | OPP справа, значения «накручиваются» 0→N за 800 мс.
class MetricRow extends StatelessWidget {
  const MetricRow({super.key, required this.metric});

  final MetricResult metric;

  @override
  Widget build(BuildContext context) {
    final lost = metric.opponentWins; // метрика отдана сопернику — красным
    final youColor = lost ? AppColors.danger : AppColors.success;
    final oppColor = lost
        ? AppColors.danger
        : AppColors.textPrimary.withValues(alpha: 0.7);
    final big = metric.isOverall;

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: big ? 12 : 9),
      decoration: BoxDecoration(
        color: lost
            ? AppColors.danger.withValues(alpha: 0.12)
            : (big ? AppColors.accent.withValues(alpha: 0.08) : Colors.transparent),
        border: Border(
          left: BorderSide(
            color: lost
                ? AppColors.danger
                : (big ? AppColors.accent : AppColors.panelBorder),
            width: 2,
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              metric.label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: AppText.mono(
                size: big ? 11 : 9.5,
                weight: big ? FontWeight.w800 : FontWeight.w500,
                color: lost ? AppColors.danger : AppColors.textPrimary,
                letterSpacing: 0.4,
              ),
            ),
          ),
          _Value(tag: 'YOU', value: metric.you, color: youColor, big: big, bold: true),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 6),
            child: Text('|', style: AppText.mono(size: 12, color: AppColors.textMuted)),
          ),
          _Value(tag: 'OPP', value: metric.opp, color: oppColor, big: big, bold: lost),
        ],
      ),
    );
  }
}

class _Value extends StatelessWidget {
  const _Value({
    required this.tag,
    required this.value,
    required this.color,
    required this.big,
    required this.bold,
  });

  final String tag;
  final double value;
  final Color color;
  final bool big;
  final bool bold;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 66, // фиксированная ширина — колонки не «прыгают» во время счёта
      child: TweenAnimationBuilder<double>(
        tween: Tween(begin: 0, end: value),
        duration: const Duration(milliseconds: 800),
        curve: Curves.easeOutCubic,
        builder: (context, v, _) => Text.rich(
          TextSpan(
            children: [
              TextSpan(
                text: '$tag ',
                style: AppText.mono(size: 8, color: AppColors.textMuted),
              ),
              TextSpan(
                text: v.toStringAsFixed(1).padLeft(4),
                style: AppText.mono(
                  size: big ? 13 : 12,
                  weight: bold ? FontWeight.w800 : FontWeight.w500,
                  color: color,
                ),
              ),
            ],
          ),
          textAlign: TextAlign.right,
          maxLines: 1,
        ),
      ),
    );
  }
}
