import 'dart:io';

import 'package:flutter/material.dart';

import '../../../../core/constants/colors.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/face_detector.dart';
import '../../../../core/widgets/corner_brackets.dart';
import '../../../../core/widgets/hud_panel.dart';

/// Фото + рамка лица + точки + бегущая скан-линия.
class ScanningFace extends StatefulWidget {
  const ScanningFace({
    super.key,
    required this.file,
    required this.scan,
    required this.label,
    required this.color,
  });

  final File file;

  /// null — детекция ещё идёт, рисуется только скан-линия.
  final FaceScan? scan;
  final String label;
  final Color color;

  @override
  State<ScanningFace> createState() => _ScanningFaceState();
}

class _ScanningFaceState extends State<ScanningFace>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 2200))
        ..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final locked = widget.scan != null;
    return HudPanel(
      accent: widget.color,
      padding: const EdgeInsets.all(3),
      glow: true,
      child: ClipRect(
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.file(widget.file, fit: BoxFit.cover, cacheWidth: 700),
            // reveal 0→1, когда рамка найдена
            TweenAnimationBuilder<double>(
              tween: Tween(begin: 0, end: locked ? 1 : 0),
              duration: const Duration(milliseconds: 800),
              curve: Curves.easeOut,
              builder: (context, reveal, _) => AnimatedBuilder(
                animation: _c,
                builder: (context, _) => CustomPaint(
                  painter: _ScanPainter(
                    scan: widget.scan,
                    t: _c.value,
                    reveal: reveal,
                    color: widget.color == AppColors.danger
                        ? AppColors.danger
                        : AppColors.accent,
                  ),
                ),
              ),
            ),
            Positioned(
              left: 4,
              top: 4,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                color: Colors.black54,
                child: Text(
                  locked ? '${widget.label} // LOCK' : '${widget.label} // ...',
                  style: AppText.mono(size: 8, color: widget.color, letterSpacing: 1),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ScanPainter extends CustomPainter {
  _ScanPainter({
    required this.scan,
    required this.t,
    required this.reveal,
    required this.color,
  });

  final FaceScan? scan;
  final double t;
  final double reveal;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    // ── Скан-линия со шлейфом ──
    final y = t * size.height;
    final trail = Rect.fromLTWH(0, y - 40, size.width, 40);
    canvas.drawRect(
      trail,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [color.withValues(alpha: 0), color.withValues(alpha: 0.28)],
        ).createShader(trail),
    );
    canvas.drawLine(
      Offset(0, y),
      Offset(size.width, y),
      Paint()
        ..color = color.withValues(alpha: 0.6)
        ..strokeWidth = 4
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
    );
    canvas.drawLine(
      Offset(0, y),
      Offset(size.width, y),
      Paint()
        ..color = color
        ..strokeWidth = 1.5,
    );

    final s = scan;
    if (s == null || reveal <= 0) return;

    // ── Рамка лица: свечение + белые уголки ──
    final r = s.rectToView(s.faceRect, size);
    canvas.drawRect(
      r,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..color = color.withValues(alpha: 0.35 * reveal)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
    );
    canvas.save();
    canvas.translate(r.left, r.top);
    CornerBracketsPainter(
      color: Colors.white.withValues(alpha: 0.9 * reveal),
      length: r.shortestSide * 0.18,
      strokeWidth: 1.2,
    ).paint(canvas, r.size);
    canvas.restore();

    // ── Точки: глаза, нос, рот ──
    final pts = {
      for (final e in s.landmarks.entries) e.key: s.toView(e.value, size),
    };
    final linePaint = Paint()
      ..color = color.withValues(alpha: 0.4 * reveal)
      ..strokeWidth = 0.8;
    final le = pts['leftEye'], re = pts['rightEye'];
    final nose = pts['nose'], mouth = pts['mouth'];
    if (le != null && re != null && nose != null && mouth != null) {
      canvas.drawLine(le, re, linePaint);
      canvas.drawLine(le, nose, linePaint);
      canvas.drawLine(re, nose, linePaint);
      canvas.drawLine(nose, mouth, linePaint);
    }
    final dot = Paint()..color = color.withValues(alpha: reveal);
    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = Colors.white.withValues(alpha: 0.7 * reveal);
    for (final p in pts.values) {
      canvas.drawCircle(p, 2.5, dot);
      canvas.drawCircle(p, 6 + 2 * (1 - reveal), ring);
    }
  }

  @override
  bool shouldRepaint(_ScanPainter old) =>
      old.t != t || old.reveal != reveal || old.scan != scan || old.color != color;
}

