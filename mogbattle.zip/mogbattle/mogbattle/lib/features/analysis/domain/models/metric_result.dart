import 'package:freezed_annotation/freezed_annotation.dart';

part 'metric_result.freezed.dart';
part 'metric_result.g.dart';

/// Одна метрика: значение пользователя и соперника.
@freezed
abstract class MetricResult with _$MetricResult {
  const MetricResult._();

  const factory MetricResult({
    required String id,
    required String label,
    required double you,
    required double opp,

    /// Метрика «отдана» сопернику — подсвечивается красным.
    @Default(false) bool opponentWins,

    /// Итоговая строка OVERALL AESTHETICS.
    @Default(false) bool isOverall,
  }) = _MetricResult;

  factory MetricResult.fromJson(Map<String, dynamic> json) =>
      _$MetricResultFromJson(json);

  /// Разница в пользу пользователя (в «отданной» метрике < 0).
  double get delta => you - opp;
}
