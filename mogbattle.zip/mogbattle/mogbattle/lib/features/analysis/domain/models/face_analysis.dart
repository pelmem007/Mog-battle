import 'package:freezed_annotation/freezed_annotation.dart';

import 'metric_result.dart';

part 'face_analysis.freezed.dart';
part 'face_analysis.g.dart';

/// Полный результат анализа: 8 метрик + итоговые баллы.
@freezed
abstract class FaceAnalysis with _$FaceAnalysis {
  const FaceAnalysis._();

  @JsonSerializable(explicitToJson: true)
  const factory FaceAnalysis({
    required List<MetricResult> metrics,
    required double youScore,
    required double oppScore,

    /// youScore − oppScore, всегда > 0.
    required double gap,
  }) = _FaceAnalysis;

  factory FaceAnalysis.fromJson(Map<String, dynamic> json) =>
      _$FaceAnalysisFromJson(json);

  /// Метрика, отданная сопернику (если выпала).
  MetricResult? get stolenMetric {
    for (final m in metrics) {
      if (m.opponentWins) return m;
    }
    return null;
  }

  /// «+25.6»
  String get gapLabel => '+${gap.toStringAsFixed(1)}';
}
