import 'dart:io';

import 'package:flutter/foundation.dart' show debugPrint;
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/utils/face_detector.dart';
import '../../../core/utils/fake_analyzer.dart';
import '../domain/models/face_analysis.dart';

final faceDetectorProvider =
    Provider<FaceDetector>((ref) => FaceDetector.instance);

/// Состояние анализа: фейковые метрики + реальные Haar-рамки.
class AnalysisState {
  const AnalysisState({this.analysis, this.youScan, this.oppScan});

  final FaceAnalysis? analysis;
  final FaceScan? youScan;
  final FaceScan? oppScan;

  AnalysisState copyWith({FaceScan? youScan, FaceScan? oppScan}) =>
      AnalysisState(
        analysis: analysis,
        youScan: youScan ?? this.youScan,
        oppScan: oppScan ?? this.oppScan,
      );
}

class AnalysisNotifier extends Notifier<AnalysisState> {
  @override
  AnalysisState build() => const AnalysisState();

  /// Метрики генерируются сразу (экран их показывает по одной),
  /// а рамки лиц дорисовываются, когда Haar-детекция закончится.
  Future<void> start(File you, File opponent) async {
    state = AnalysisState(analysis: FakeAnalyzer().analyze());
    try {
      final det = ref.read(faceDetectorProvider);
      final scans = await Future.wait([det.scan(you), det.scan(opponent)]);
      state = state.copyWith(youScan: scans[0], oppScan: scans[1]);
    } catch (e) {
      // Без рамок экран всё равно работает — метрики уже есть
      debugPrint('AnalysisNotifier: скан не удался: $e');
    }
  }

  void reset() => state = const AnalysisState();
}

final analysisProvider =
    NotifierProvider<AnalysisNotifier, AnalysisState>(AnalysisNotifier.new);
