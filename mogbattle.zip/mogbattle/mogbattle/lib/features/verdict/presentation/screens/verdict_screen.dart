import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:screenshot/screenshot.dart';

import '../../../../core/constants/colors.dart';
import '../../../../core/constants/strings.dart';
import '../../../../core/router/routes.dart';
import '../../../../core/widgets/hud_scaffold.dart';
import '../../../analysis/application/analysis_provider.dart';
import '../../../history/application/history_provider.dart';
import '../../../home/presentation/widgets/glow_button.dart';
import '../../../upload/application/upload_provider.dart';
import '../../application/share_service.dart';
import '../../application/verdict_provider.dart';
import '../widgets/share_card.dart';

/// Экран 6: вердикт. Композит снимается через screenshot и уходит в share_plus.
class VerdictScreen extends ConsumerStatefulWidget {
  const VerdictScreen({super.key});

  @override
  ConsumerState<VerdictScreen> createState() => _VerdictScreenState();
}

class _VerdictScreenState extends ConsumerState<VerdictScreen> {
  final _shot = ScreenshotController();
  double _cardWidth = 270; // реальная ширина карточки на экране
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _init());
  }

  Future<void> _init() async {
    final v = ref.read(verdictProvider);
    if (v == null) {
      context.go(AppRoutes.home);
      return;
    }
    HapticFeedback.heavyImpact();
    // Пишем баттл в историю (экран создаётся один раз за баттл)
    await ref.read(historyProvider.notifier).add(
          you: v.you,
          opponent: v.opponent,
          youScore: v.analysis.youScore,
          oppScore: v.analysis.oppScore,
          gap: v.analysis.gap,
        );
  }

  Future<void> _share() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      // Рендерим в 1080 px по ширине (формат TikTok 1080×1920)
      final ratio = min(6.0, max(1.0, 1080 / _cardWidth));
      final bytes = await _shot.capture(
        pixelRatio: ratio,
        delay: const Duration(milliseconds: 50),
      );
      if (bytes == null) throw StateError('Пустой снимок');
      await ShareService.sharePng(bytes);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('// EXPORT FAILED. TRY AGAIN')),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _scanAgain() {
    ref.read(uploadProvider.notifier).reset();
    ref.read(analysisProvider.notifier).reset();
    // home → upload, чтобы системная «назад» вела на главный
    context.go(AppRoutes.home);
    context.push(AppRoutes.upload);
  }

  @override
  Widget build(BuildContext context) {
    final v = ref.watch(verdictProvider);
    if (v == null) return const HudScaffold(child: SizedBox.shrink());

    return HudScaffold(
      leftLabel: '// VERDICT',
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
      child: Column(
        children: [
          Expanded(
            child: Center(
              child: AspectRatio(
                aspectRatio: ShareCard.width / ShareCard.height,
                child: LayoutBuilder(
                  builder: (context, box) {
                    _cardWidth = box.maxWidth;
                    return Screenshot(
                      controller: _shot,
                      child: FittedBox(
                        fit: BoxFit.contain,
                        child: ShareCard(
                          you: v.you,
                          opponent: v.opponent,
                          analysis: v.analysis,
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          GlowButton(
            label: _busy ? 'RENDERING...' : AppStrings.shareToTiktok,
            icon: Icons.ios_share_rounded,
            color: AppColors.gold,
            onPressed: _busy ? null : _share,
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: GlowButton(
                  label: AppStrings.scanAgain,
                  compact: true,
                  onPressed: _scanAgain,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: GlowButton(
                  label: AppStrings.viewHistory,
                  compact: true,
                  onPressed: () => context.push(AppRoutes.history),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
