import 'dart:io';

import 'package:flutter/material.dart';

import '../../../../core/constants/colors.dart';
import '../../../../core/constants/strings.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/widgets/hud_panel.dart';
import '../../../analysis/domain/models/face_analysis.dart';
import 'mogged_overlay.dart';

/// Композит вердикта 360×640 (9:16). Его же снимает screenshot для TikTok.
class ShareCard extends StatelessWidget {
  const ShareCard({
    super.key,
    required this.you,
    required this.opponent,
    required this.analysis,
    this.animate = true,
  });

  static const width = 360.0;
  static const height = 640.0;

  final File you;
  final File opponent;
  final FaceAnalysis analysis;
  final bool animate;

  @override
  Widget build(BuildContext context) {
    final stolen = analysis.stolenMetric;
    final muted = AppText.mono(size: 10, color: AppColors.textMuted, letterSpacing: 1.5);

    return SizedBox(
      width: width,
      height: height,
      child: DecoratedBox(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, -0.3),
            radius: 1.1,
            colors: [Color(0xFF14202E), AppColors.background],
          ),
        ),
        child: Stack(
          children: [
            const Positioned.fill(child: CustomPaint(painter: _GridPainter())),

            // Шапка
            Positioned(
              top: 14,
              left: 18,
              right: 18,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('// MOG BATTLE RESULT', style: muted),
                  Text('[REC]', style: muted.copyWith(color: AppColors.danger)),
                ],
              ),
            ),

            // Соперник: маленький, затемнённый, MOGGED поперёк
            Positioned(
              top: 48,
              right: 18,
              width: 92,
              height: 92,
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(color: AppColors.danger.withValues(alpha: 0.6)),
                ),
                child: MoggedOverlay(
                  animate: animate,
                  child: Image.file(opponent, fit: BoxFit.cover, cacheWidth: 300),
                ),
              ),
            ),

            // Подпись MOGGER
            Positioned(
              top: 98,
              left: 24,
              child: Text(
                AppStrings.mogger,
                style: AppText.mono(
                  size: 26,
                  weight: FontWeight.w800,
                  color: AppColors.gold,
                  letterSpacing: 5,
                ).copyWith(
                  shadows: [Shadow(color: AppColors.gold.withValues(alpha: 0.6), blurRadius: 16)],
                ),
              ),
            ),

            // Ты: большое фото в золотой рамке
            Positioned(
              top: 150,
              left: 60,
              width: 240,
              height: 240,
              child: HudPanel(
                accent: AppColors.gold,
                glow: true,
                padding: const EdgeInsets.all(4),
                child: Image.file(you, fit: BoxFit.cover, cacheWidth: 900),
              ),
            ),

            // MOG GAP
            Positioned(
              top: 402,
              left: 0,
              right: 0,
              child: Column(
                children: [
                  TweenAnimationBuilder<double>(
                    tween: Tween(begin: animate ? 0 : analysis.gap, end: analysis.gap),
                    duration: const Duration(milliseconds: 1400),
                    curve: Curves.easeOutCubic,
                    builder: (context, v, _) => Text(
                      '+${v.toStringAsFixed(1)}',
                      style: AppText.mono(
                        size: 62,
                        weight: FontWeight.w800,
                        color: AppColors.textPrimary,
                      ).copyWith(
                        shadows: [
                          Shadow(color: AppColors.gold.withValues(alpha: 0.7), blurRadius: 24),
                        ],
                      ),
                    ),
                  ),
                  Text(
                    AppStrings.mogGap,
                    style: AppText.mono(
                      size: 12,
                      weight: FontWeight.w700,
                      color: AppColors.gold,
                      letterSpacing: 6,
                    ),
                  ),
                ],
              ),
            ),

            // Баллы
            Positioned(
              top: 506,
              left: 0,
              right: 0,
              child: Text.rich(
                TextSpan(
                  style: AppText.mono(size: 13, weight: FontWeight.w700, letterSpacing: 0.5),
                  children: [
                    const TextSpan(text: 'YOU: '),
                    TextSpan(
                      text: analysis.youScore.toStringAsFixed(1),
                      style: const TextStyle(color: AppColors.success),
                    ),
                    const TextSpan(text: '  |  OPPONENT: '),
                    TextSpan(
                      text: analysis.oppScore.toStringAsFixed(1),
                      style: const TextStyle(color: AppColors.danger),
                    ),
                  ],
                ),
                textAlign: TextAlign.center,
              ),
            ),

            // Если одна метрика ушла сопернику — честная пометка
            if (stolen != null)
              Positioned(
                top: 540,
                left: 20,
                right: 20,
                child: Text(
                  '// NOTE: OPPONENT LEADS IN ${stolen.label}',
                  textAlign: TextAlign.center,
                  style: AppText.mono(
                    size: 9,
                    color: AppColors.danger.withValues(alpha: 0.8),
                    letterSpacing: 0.8,
                  ),
                ),
              ),

            // Водяной знак
            Positioned(
              right: 16,
              bottom: 12,
              child: Text(
                AppStrings.watermark,
                style: AppText.mono(size: 10, color: AppColors.textMuted, letterSpacing: 1),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GridPainter extends CustomPainter {
  const _GridPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppColors.accent.withValues(alpha: 0.04)
      ..strokeWidth = 1;
    for (var x = 0.0; x <= size.width; x += 36) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (var y = 0.0; y <= size.height; y += 36) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
