import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../../../core/constants/colors.dart';
import '../../../../core/constants/strings.dart';
import '../../../../core/theme/app_theme.dart';

/// Затемнённое фото соперника (opacity 0.4) с красным штампом MOGGED под углом −15°.
class MoggedOverlay extends StatelessWidget {
  const MoggedOverlay({super.key, required this.child, this.animate = true});

  final Widget child;

  /// true — штамп «впечатывается» с задержкой.
  final bool animate;

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Opacity(opacity: 0.4, child: child),
        Center(
          child: TweenAnimationBuilder<double>(
            tween: Tween(begin: animate ? 0 : 1, end: 1),
            duration: const Duration(milliseconds: 1200),
            // Interval даёт задержку ~0.5 с до удара штампа
            curve: const Interval(0.4, 1, curve: Curves.easeOutBack),
            builder: (context, v, _) => Opacity(
              opacity: v.clamp(0.0, 1.0),
              child: Transform.rotate(
                angle: -15 * math.pi / 180,
                child: Transform.scale(
                  scale: 1 + (1 - v) * 1.6,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                    decoration: BoxDecoration(
                      border: Border.all(color: AppColors.danger, width: 2),
                      color: AppColors.background.withValues(alpha: 0.55),
                    ),
                    child: Text(
                      AppStrings.mogged,
                      style: AppText.mono(
                        size: 14,
                        weight: FontWeight.w800,
                        color: AppColors.danger,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
