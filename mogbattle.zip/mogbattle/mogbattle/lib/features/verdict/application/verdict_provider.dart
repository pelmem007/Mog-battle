import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../analysis/application/analysis_provider.dart';
import '../../analysis/domain/models/face_analysis.dart';
import '../../upload/application/upload_provider.dart';

/// Всё, что нужно экрану вердикта.
class VerdictData {
  const VerdictData({required this.you, required this.opponent, required this.analysis});

  final File you;
  final File opponent;
  final FaceAnalysis analysis;
}

/// null — вердикта ещё нет (например, экран открыт «с нуля»).
final verdictProvider = Provider<VerdictData?>((ref) {
  final up = ref.watch(uploadProvider);
  final an = ref.watch(analysisProvider).analysis;
  if (!up.ready || an == null) return null;
  return VerdictData(you: up.you!, opponent: up.opponent!, analysis: an);
});
