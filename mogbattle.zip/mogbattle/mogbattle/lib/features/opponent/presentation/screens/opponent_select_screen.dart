import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/strings.dart';
import '../../../../core/router/routes.dart';
import '../../../../core/widgets/hud_scaffold.dart';
import '../../../upload/application/upload_provider.dart';
import '../widgets/opponent_card.dart';

/// Экран 2: выбор типа соперника. Что бы ни выбрали — итог один.
class OpponentSelectScreen extends ConsumerWidget {
  const OpponentSelectScreen({super.key});

  static const _icons = <IconData>[
    Icons.face_retouching_natural,
    Icons.theaters,
    Icons.trending_up,
    Icons.add_photo_alternate_outlined,
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return HudScaffold(
      title: AppStrings.selectOpponent,
      showBack: true,
      child: Padding(
        padding: const EdgeInsets.only(top: 16),
        child: GridView.count(
          crossAxisCount: 2,
          mainAxisSpacing: 14,
          crossAxisSpacing: 14,
          physics: const NeverScrollableScrollPhysics(),
          children: [
            for (var i = 0; i < AppStrings.opponentTypes.length; i++)
              OpponentCard(
                label: AppStrings.opponentTypes[i],
                icon: _icons[i],
                onTap: () async {
                  // Открываем галерею; выбранное фото сразу попадает в слот соперника
                  final picked = await ref.read(uploadProvider.notifier).pickOpponent();
                  if (picked && context.mounted) context.push(AppRoutes.upload);
                },
              ),
          ],
        ),
      ),
    );
  }
}
