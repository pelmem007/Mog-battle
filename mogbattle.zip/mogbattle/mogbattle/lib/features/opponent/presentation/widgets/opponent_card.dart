import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../../core/constants/colors.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/widgets/hud_panel.dart';

/// Карточка типа соперника (MODEL / ACTOR / INFLUENCER / CUSTOM PHOTO).
class OpponentCard extends StatelessWidget {
  const OpponentCard({
    super.key,
    required this.label,
    required this.icon,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return HudPanel(
      onTap: () {
        HapticFeedback.selectionClick();
        onTap();
      },
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.accent.withValues(alpha: 0.5)),
              color: AppColors.accent.withValues(alpha: 0.08),
            ),
            child: Icon(icon, size: 28, color: AppColors.accent),
          ),
          const SizedBox(height: 14),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              label,
              style: AppText.mono(size: 14, weight: FontWeight.w700, letterSpacing: 1.5),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            '// LOAD FROM GALLERY',
            style: AppText.mono(size: 8, color: AppColors.textMuted),
          ),
        ],
      ),
    );
  }
}
